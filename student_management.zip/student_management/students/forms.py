from django import forms
from .models import Student

class StudentForm(forms.ModelForm):
    class Meta:
        model = Student
        fields = [
            'registration_number', 'name', 'student_class', 'session', 'section',
            'total_fees', 'paid_fees', 'father_name',
            'father_contact_no', 'father_email',
            'mother_name', 'mother_contact_no', 'mother_email'
        ]
        widgets = {
            'total_fees': forms.NumberInput(attrs={'step': '0.01'}),
            'paid_fees': forms.NumberInput(attrs={'step': '0.01'}),
        }
