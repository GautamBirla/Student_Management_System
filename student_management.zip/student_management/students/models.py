from django.db import models

class Student(models.Model):
    registration_number = models.CharField(max_length=20, unique=True)
    name = models.CharField(max_length=100)
    student_class = models.CharField(max_length=10)
    session = models.CharField(max_length=20)
    section = models.CharField(max_length=10)
    total_fees = models.FloatField()
    paid_fees = models.FloatField()
    due_fees = models.FloatField(editable=False)  # Calculated field
    father_name = models.CharField(max_length=100)
    father_contact_no = models.CharField(max_length=15)
    father_email = models.EmailField()
    mother_name = models.CharField(max_length=100)
    mother_contact_no = models.CharField(max_length=15)
    mother_email = models.EmailField()

    def save(self, *args, **kwargs):
        self.due_fees = self.total_fees - self.paid_fees
        super().save(*args, **kwargs)

    def __str__(self):
        return self.name
