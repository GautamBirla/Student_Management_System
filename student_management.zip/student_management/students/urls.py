from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('add/', views.add_student, name='add_student'),
    path('view/', views.view_students, name='view_students'),
    path('edit/<int:pk>/', views.edit_student, name='edit_student'),
    path('delete/<int:pk>/', views.delete_student, name='delete_student'),
    path('filter/', views.filter_students, name='filter_students'),
    path('filter_students/', views.filter_students, name='filter_students'),
]
