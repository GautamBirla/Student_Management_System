from django.shortcuts import render, redirect, get_object_or_404
from .models import Student
from .forms import StudentForm

def home(request):
    return render(request, 'students/home.html')

def add_student(request):
    if request.method == 'POST':
        form = StudentForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('view_students')
    else:
        form = StudentForm()
    return render(request, 'students/add_student.html', {'form': form})

def view_students(request):
    students = Student.objects.all()
    return render(request, 'students/view_students.html', {'students': students})

def edit_student(request, pk):
    student = get_object_or_404(Student, pk=pk)
    if request.method == 'POST':
        form = StudentForm(request.POST, instance=student)
        if form.is_valid():
            form.save()
            return redirect('view_students')
    else:
        form = StudentForm(instance=student)
    return render(request, 'students/edit_student.html', {'form': form})

def delete_student(request, pk):
    student = get_object_or_404(Student, pk=pk)
    if request.method == 'POST':
        student.delete()
        return redirect('view_students')
    return render(request, 'students/delete_student.html', {'student': student})

def filter_students(request):
    registration_id = request.GET.get('registration_id', '')
    student_class = request.GET.get('class', '')
    session = request.GET.get('session', '')
    section = request.GET.get('section', '')
    name = request.GET.get('name', '')

    # Filter students based on the query parameters
    students = Student.objects.all()

    if registration_id:
        students = students.filter(registration_number__icontains=registration_id)
    if student_class:
        students = students.filter(student_class=student_class)
    if session:
        students = students.filter(session=session)
    if section:
        students = students.filter(section=section)
    if name:
        students = students.filter(name__icontains=name)

    # Optional: Pass available choices for filters to the template
    classes = Student.objects.values_list('student_class', flat=True).distinct()
    sessions = Student.objects.values_list('session', flat=True).distinct()
    sections = Student.objects.values_list('section', flat=True).distinct()

    return render(request, 'students/filter_students.html', {
        'students': students,
        'classes': classes,
        'sessions': sessions,
        'sections': sections,
    })
