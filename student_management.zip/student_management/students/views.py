from django.shortcuts import render, redirect, get_object_or_404
from .models import Student
from .forms import StudentForm

def home(request):
    return render(request, 'students/home.html')

def add_student(request):
    if request.method == 'POST':
        form = StudentForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('view_students')
    else:
        form = StudentForm()
    return render(request, 'students/add_student.html', {'form': form})

def view_students(request):
    students = Student.objects.all()
    return render(request, 'students/view_students.html', {'students': students})

def edit_student(request, pk):
    student = get_object_or_404(Student, pk=pk)
    if request.method == 'POST':
        form = StudentForm(request.POST, instance=student)
        if form.is_valid():
            form.save()
            return redirect('view_students')
    else:
        form = StudentForm(instance=student)
    return render(request, 'students/edit_student.html', {'form': form})

def delete_student(request, pk):
    student = get_object_or_404(Student, pk=pk)
    if request.method == 'POST':
        student.delete()
        return redirect('view_students')
    return render(request, 'students/delete_student.html', {'student': student})

def filter_students(request):
    registration_id = request.GET.get('registration_id')
    students = Student.objects.all()
    student_detail = None

    if registration_id:
        student_detail = get_object_or_404(Student, registration_number=registration_id)
    
    student_filter_params = {
        'classes': Student.objects.values_list('student_class', flat=True).distinct(),
        'sessions': Student.objects.values_list('session', flat=True).distinct(),
        'sections': Student.objects.values_list('section', flat=True).distinct(),
        'students': students,
        'student_detail': student_detail
    }

    return render(request, 'students/filter_students.html', student_filter_params)
    return render(request, 'filter_students.html', student_filter_params)
